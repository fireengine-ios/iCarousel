//
//  MyNavigationController.h
//  Depo
//
//  Created by mahir tarlan
//  Copyright (c) 2013 igones. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNavigationController : UINavigationController

- (void) hideNavigationBar;
- (void) showNavigationBar;

@end
