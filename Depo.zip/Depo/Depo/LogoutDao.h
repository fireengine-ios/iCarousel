//
//  LogoutDao.h
//  Depo
//
//  Created by Mahir on 31/01/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "BaseDao.h"

@interface LogoutDao : BaseDao

- (void) requestLogout;

@end
