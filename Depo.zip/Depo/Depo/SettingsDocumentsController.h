//
//  SettingsDocumentsController.h
//  Depo
//
//  Created by Mustafa Talha Celik on 26.09.2014.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "SettingsBaseViewController.h"

@interface SettingsDocumentsController : SettingsBaseViewController {
    NSString *infoTextOn;
    double infoTextOnHeight;
    NSString *infoTextOff;
    double infoTextOffHeight;
}

@end
