//
//  Activity.m
//  Depo
//
//  Created by Mahir on 19.11.2014.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "Activity.h"

@implementation Activity

@synthesize activityId;
@synthesize date;
@synthesize visibleHour;
@synthesize title;
@synthesize activityType;
@synthesize actionItemList;
@synthesize fileUuid;
@synthesize name;
@synthesize rawActivityType;
@synthesize rawFileType;

@end
