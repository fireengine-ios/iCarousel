//
//  HomeUsageView.h
//  Depo
//
//  Created by Mahir on 30.11.2014.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Usage.h"

@interface HomeUsageView : UIView

- (id) initWithFrame:(CGRect)frame withUsage:(Usage *) usage;

@end
