//
//  Offer.m
//  Depo
//
//  Created by Salih Topcu on 07.01.2015.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "Offer.h"

@implementation Offer

@synthesize offerId;
@synthesize name;
@synthesize campaignChannel;
@synthesize campaignCode;
@synthesize campaignId;
@synthesize campaignUserCode;
@synthesize cometParameters;
@synthesize responseApi;
@synthesize validationKey;
@synthesize price;
@synthesize role;
@synthesize quotaString;
@synthesize quota;
@synthesize period;
@synthesize rawPrice;

@end
