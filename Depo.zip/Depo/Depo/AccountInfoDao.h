//
//  AccountInfoDao.h
//  Depo
//
//  Created by Mahir on 25/01/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "BaseDao.h"

@interface AccountInfoDao : BaseDao

- (void) requestAccountInfo;

@end
