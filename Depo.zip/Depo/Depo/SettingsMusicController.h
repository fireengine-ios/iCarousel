//
//  SettingsMusicController.h
//  Depo
//
//  Created by Mustafa Talha Celik on 26.09.2014.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "SettingsBaseViewController.h"

@interface SettingsMusicController : SettingsBaseViewController {
    NSString *infoTextOn;
    double infoTextOnHeight;
    NSString *infoTextOff;
    double infoTextOffHeight;
}

@end
