//
//  SettingsAboutUsController.h
//  Depo
//
//  Created by Salih Topcu on 05.01.2015.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "SettingsBaseViewController.h"

@interface SettingsAboutUsController : SettingsBaseViewController <UIWebViewDelegate>

@end
