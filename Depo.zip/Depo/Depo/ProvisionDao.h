//
//  ProvisionDao.h
//  Depo
//
//  Created by Mahir on 03/02/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "BaseDao.h"

@interface ProvisionDao : BaseDao

- (void) requestSendProvision;

@end
