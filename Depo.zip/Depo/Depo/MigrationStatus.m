//
//  MigrationStatus.m
//  Depo
//
//  Created by Mahir on 03/02/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "MigrationStatus.h"

@implementation MigrationStatus

@synthesize progress;
@synthesize status;

@end
