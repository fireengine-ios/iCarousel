//
//  PostLoginSyncContactController.h
//  Depo
//
//  Created by Mahir on 5.12.2014.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "MyViewController.h"

@interface PostLoginSyncContactController : MyViewController

@property (nonatomic, strong) UISwitch *onOff;

@end
