#import <UIKit/UIKit.h>

@interface NSMutableArray (Shuffling)

- (void)shuffle;

@end