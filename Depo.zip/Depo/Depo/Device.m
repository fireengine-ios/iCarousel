//
//  Device.m
//  Depo
//
//  Created by Salih Topcu on 12.01.2015.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "Device.h"

@implementation Device

@synthesize name;
@synthesize type;

@end
