//
//  MetaAlbum.m
//  Depo
//
//  Created by Mahir on 10/3/14.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "MetaAlbum.h"

@implementation MetaAlbum

@synthesize albumName;
@synthesize thumbnailImg;
@synthesize count;

@end
