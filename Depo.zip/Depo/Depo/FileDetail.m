//
//  FileDetail.m
//  Depo
//
//  Created by Mahir on 9/29/14.
//  Copyright (c) 2014 com.igones. All rights reserved.
//

#import "FileDetail.h"

@implementation FileDetail

@synthesize favoriteFlag;
@synthesize thumbLargeUrl;
@synthesize thumbMediumUrl;
@synthesize thumbSmallUrl;
@synthesize width;
@synthesize height;
@synthesize genre;
@synthesize artist;
@synthesize album;
@synthesize songTitle;
@synthesize duration;

@end
