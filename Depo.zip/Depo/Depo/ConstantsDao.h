//
//  ConstantsDao.h
//  Depo
//
//  Created by Mahir on 18/03/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "BaseDao.h"

@interface ConstantsDao : BaseDao

- (void) requestConstants;

@end
