//
//  ContactCountDao.h
//  Depo
//
//  Created by Mahir on 16/03/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "BaseDao.h"

@interface ContactCountDao : BaseDao

- (void) requestContactCount;

@end
