//
//  OfferContainer.m
//  Depo
//
//  Created by gurhan on 05/05/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import "OfferContainer.h"

@implementation OfferContainer

@synthesize montlyOffer;
@synthesize yearlyOffer;
@synthesize quota;

@end
