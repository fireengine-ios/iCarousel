//
//  AuthResponse.m
//  Acdm_1
//
//  Created by mahir tarlan on 12/30/13.
//  Copyright (c) 2013 igones. All rights reserved.
//

#import "AuthResponse.h"

@implementation AuthResponse

@synthesize code;
@synthesize message;
@synthesize isSuccess;
@synthesize rememberMe;
@synthesize showCaptcha;
@synthesize authToken;
@synthesize username;
@synthesize clientSecret;

@end
