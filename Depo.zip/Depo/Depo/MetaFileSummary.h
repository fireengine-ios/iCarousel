//
//  MetaFileSummary.h
//  Depo
//
//  Created by Mahir on 20/03/15.
//  Copyright (c) 2015 com.igones. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaFileSummary : NSObject

@property (nonatomic) long long bytes;
@property (nonatomic, strong) NSString *fileName;

@end
