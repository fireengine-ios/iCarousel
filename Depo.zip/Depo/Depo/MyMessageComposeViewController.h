//
//  MyMessageComposeViewController.h
//  Depo
//
//  Created by Mahir on 6/10/14.
//  Copyright (c) 2014 igones. All rights reserved.
//

#import <MessageUI/MessageUI.h>

@interface MyMessageComposeViewController : MFMessageComposeViewController

@end
